// Minimal client app — loads questions, supports timer, nav, review, CSV export.
const $ = (q, d=document)=>d.querySelector(q);
const $$=(q, d=document)=>[...d.querySelectorAll(q)];

const STORAGE_KEY='kau_bb_exam_state_v1';
const DURATION_MIN=35;

let QUESTIONS=[], order=[], answers=[], flags=[], current=0, startedAt=null, timerId=null;

async function boot(){
  // Clock
  setInterval(()=>{ $("#clock").textContent=new Date().toLocaleString('ar-SA') }, 1000);

  // Load questions
  const qRes = await fetch('questions.json');
  QUESTIONS = await qRes.json();

  // Fill count options
  const qc = $("#questionCount");
  [10,20,30,QUESTIONS.length].forEach(n=>{
    const o=document.createElement('option');
    o.value = String(Math.min(n, QUESTIONS.length));
    o.textContent = String(Math.min(n, QUESTIONS.length));
    qc.appendChild(o);
  });
  qc.value = String(Math.min(30, QUESTIONS.length));

  // Buttons
  $("#btnStart").onclick = startExam;
  $("#btnReset").onclick = ()=>{ localStorage.removeItem(STORAGE_KEY); location.reload(); };

  $("#btnPrev").onclick = ()=>show(current-1);
  $("#btnNext").onclick = ()=>show(current+1);
  $("#btnFlag").onclick = toggleFlag;
  $("#btnSubmit").onclick = submitExam;

  $("#btnReview").onclick = ()=>$("#reviewPanel").classList.toggle('hidden');
  $("#btnExport").onclick = exportCSV;
  $("#btnRestart").onclick = ()=>location.reload();

  // Restore
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
  if(saved && saved.finished){
    QUESTIONS=saved.questions; order=saved.order; answers=saved.answers; flags=saved.flags;
    $("#s-intro").classList.add('hidden'); $("#s-result").classList.remove('hidden');
    renderScore();
  }
}

function setupOrder(n,mode){
  order = [...Array(n).keys()];
  if(mode==='shuffle'){
    for(let i=order.length-1;i>0;--i){ const j=Math.floor(Math.random()*(i+1)); [order[i],order[j]]=[order[j],order[i]]; }
  }
}

function startExam(){
  const name=$("#studentName").value.trim()||'طالب/ـة';
  const group=$("#studentGroup").value.trim();
  const n=parseInt($("#questionCount").value,10);
  const mode=$("#orderMode").value;

  setupOrder(n,mode);
  answers = Array(n).fill(null);
  flags = Array(n).fill(false);
  startedAt = Date.now();

  $("#candidate").textContent = group? `${name} — ${group}` : name;
  $("#qCountLabel").textContent = n;
  $("#startedAt").textContent = new Date(startedAt).toLocaleTimeString('ar-SA');

  $("#s-intro").classList.add('hidden');
  $("#s-exam").classList.remove('hidden');

  buildNav(n);
  show(0);

  // Timer
  const end = startedAt + DURATION_MIN*60*1000;
  timerId = setInterval(()=>{
    const now=Date.now(); let remain = Math.max(0, end-now);
    const mm = String(Math.floor(remain/60000)).padStart(2,'0');
    const ss = String(Math.floor((remain%60000)/1000)).padStart(2,'0');
    $("#remaining").textContent=`${mm}:${ss}`;
    if(remain<=0){ clearInterval(timerId); submitExam(); }
  }, 500);

  persist();
}

function buildNav(n){
  const nav=$("#navGrid"); nav.innerHTML='';
  for(let i=0;i<n;i++){
    const b=document.createElement('button');
    b.textContent=String(i+1);
    b.onclick=()=>show(i);
    nav.appendChild(b);
  }
}

function persist(finished=false){
  localStorage.setItem(STORAGE_KEY, JSON.stringify({questions:QUESTIONS, order, answers, flags, finished}));
}

function show(i){
  const n = order.length;
  current = (i<0?0:(i>=n?n-1:i));
  const qi = order[current];
  const q = QUESTIONS[qi];

  // panel
  const el = $("#questionPanel"); el.innerHTML = '';
  const title = document.createElement('h3'); title.className='q-title'; title.textContent=`س${current+1}. ${q.prompt}`; el.appendChild(title);

  const opts = document.createElement('div'); opts.className='options';
  q.options.forEach((t, idx)=>{
    const wrap=document.createElement('div'); wrap.className='option';
    const radio=document.createElement('input'); radio.type='radio'; radio.name='opt'; radio.checked=(answers[current]===idx);
    radio.onchange=()=>{ answers[current]=idx; updateNavState(); persist(); };
    const label=document.createElement('label'); label.textContent=`${'أ ب ج د'.split(' ')[idx] || ''} — ${t}`;
    wrap.appendChild(radio); wrap.appendChild(label); opts.appendChild(wrap);
  });
  el.appendChild(opts);

  // Footer state
  updateNavState();
  // Prev/Next state
  $("#btnPrev").disabled = current===0;
  $("#btnNext").disabled = current===order.length-1;
  $("#btnFlag").setAttribute('aria-pressed', flags[current] ? 'true':'false');
}

function updateNavState(){
  const n=order.length; const answered = answers.filter(a=>a!==null).length;
  $("#answeredLabel").textContent = answered;
  $("#progress").style.width = `${Math.round(answered/n*100)}%`;

  $$("#navGrid button").forEach((b, i)=>{
    b.classList.toggle('answered', answers[i]!==null);
    b.classList.toggle('flag', flags[i]);
  });
  persist();
}

function toggleFlag(){
  flags[current] = !flags[current];
  $("#btnFlag").setAttribute('aria-pressed', flags[current] ? 'true':'false');
  updateNavState();
}

function submitExam(){
  clearInterval(timerId);
  const key = order.map(i=>QUESTIONS[i].answerIndex);
  let score=0;
  order.forEach((qi, idx)=>{ if(answers[idx]===QUESTIONS[qi].answerIndex) score++; });
  $("#s-exam").classList.add('hidden');
  $("#s-result").classList.remove('hidden');
  renderScore(score, order.length, key);
  persist(true);
}

function renderScore(score=null, total=null, key=null){
  if(score===null){
    // restored state
    total = order.length;
    const restoredKey = order.map(i=>QUESTIONS[i].answerIndex);
    let s = 0; order.forEach((qi, idx)=>{ if(answers[idx]===QUESTIONS[qi].answerIndex) s++; });
    score = s; key = restoredKey;
  }
  $("#scoreLine").textContent = `نتيجتك: ${score} / ${total} — ${Math.round(score/total*100)}%`;
  const r = $("#reviewPanel"); r.innerHTML='';
  order.forEach((qi, idx)=>{
    const q = QUESTIONS[qi];
    const div=document.createElement('div'); div.className='cardy';
    const chosen = answers[idx];
    const correct = q.answerIndex;
    div.innerHTML = `<strong>س${idx+1}.</strong> ${q.prompt}<br>
      <em>اختيارك:</em> ${chosen===null? '—' : (q.options[chosen])}
      <br><span class="${chosen===correct?'correct':'wrong'}"><em>الإجابة الصحيحة:</em> ${q.options[correct]}</span>`;
    r.appendChild(div);
  });
}

function exportCSV(){
  const rows = [['index','prompt','A','B','C','D','correctIndex','chosenIndex']];
  order.forEach((qi, idx)=>{
    const q = QUESTIONS[qi];
    rows.push([idx+1, q.prompt, ...q.options, q.answerIndex, answers[idx]]);
  });
  const csv = rows.map(r=>r.map(x=>`"${String(x).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'results.csv';
  a.click();
}

boot();
