# KAU Blackboard-like Exam (Static)

Open index.html to run locally.
